/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package soal3;

/**
 *
 * @author Muhammad Edo Wardaya
 */
class Mobil {
    
    private final String merk;
    private final double kecepatan;
    
    public Mobil(String nilaiMerk, double nilaiKecepatan){
        System.out.println("=== DATA DARI CLASS MOBIL ===");
        this.merk = nilaiMerk;
        this.kecepatan = nilaiKecepatan;
        this.cetak();
    }
    
    private void cetak(){
        System.out.println("Merk Mobil : " + merk);
        System.out.println("Kecepatan Mobil : " + kecepatan);
    }
    
    class Pengguna {
        
        private final String nama;
        private final int usia;
        
        public Pengguna(String nilaiNama, int nilaiUsia) {
            this.nama = nilaiNama;
            this.usia = nilaiUsia;
            System.out.println("=== DATA DARI CLASS PENGGUNA ===");
            this.cetak();
        }
        
        private void cetak(){
            System.out.println("Nama Saya : " + nama);
            System.out.println("Usia Saya : " + usia);
        }
    }
    
     public static void main(String[] args) {
        
        Mobil Suzuki = new Mobil("Suzuki",360.0);
        Mobil.Pengguna Wildan = Suzuki.new Pengguna("Wildan",19);
        
    }
}
   

