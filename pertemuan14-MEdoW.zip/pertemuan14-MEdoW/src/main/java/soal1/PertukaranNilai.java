package soal1;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Muhammad Edo Wardaya
 */
public class PertukaranNilai {
    private Object dataSatu;
    private Object dataDua;
    private Object temp;
    
    public PertukaranNilai(){
        System.out.println("Pertukaran Nilai");
    }
    
    public void DataSatu(Object value){
        this.dataSatu = value;
    }
    
    public void DataDua(Object value){
        this.dataDua = value;
    }
    
    public void result(){
        temp = dataSatu;
        dataSatu = dataDua;
        dataDua = temp;
        
        System.out.println("Nilai variabel satu sesudah ditukar " + dataSatu);
        System.out.println("Nilai variabel dua sesudah ditukar = " + dataDua);
    }
    
}

class Tester {
    public static void main(String[] args) {
        PertukaranNilai nilaiSaya = new PertukaranNilai();
        nilaiSaya.DataSatu(10);
        nilaiSaya.DataDua(20);
        nilaiSaya.result();
        nilaiSaya.DataSatu("Budi");
        nilaiSaya.DataDua("Sunny");
        nilaiSaya.result();
    }
}